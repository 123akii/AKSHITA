export const environment = {
  production: false,
  host: 'http://localhost:8080'
}
